We use `combine_data.ipynb` to combine 
1. `cc-est2019-alldata.csv`;
2. `PovertyEstimates.csv`;
3. `County_Rural_Lookup.csv`;
4. `county_pop_risk_covid.csv`;
into a dataframe called `data_non-covid.csv`.


We need to rerun `combine_data.ipynb` when any of the four files is changed. 

